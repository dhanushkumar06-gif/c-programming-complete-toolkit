# C Programming Complete Toolkit

A beginner-friendly, menu-driven C console application designed around a five-unit introductory C programming syllabus. It combines common lab exercises into one application, making it suitable for learning, demonstration, and a GitHub portfolio.

## Features mapped to the syllabus

### Unit I — Introduction to Problem-Solving Techniques
- Algorithm and complexity notes
- Factorial using iterative and recursive methods
- Fibonacci sequence
- Linear search
- Bubble sort
- Sum of digits
- Anagram checker
- Pseudocode and flowchart guidance

### Unit II — C Programming Basics
- Variables, constants, data types, operators and input/output notes
- `if` / `else` branching and grade calculation
- `for`, `while` and `do-while` loop demonstration
- Student grade calculator

### Unit III — Arrays and Strings
- One-dimensional array sum, minimum and maximum
- Two-dimensional matrix addition
- String length, reverse and lowercase conversion
- Array sorting and searching

### Unit IV — Functions and Pointers
- Recursive function
- Pointer address and dereference operators
- Pointer-based value modification
- Array of pointers to strings
- Pass-by-value versus pointer-based modification demonstration

> C passes arguments by value. The pointer example demonstrates how a function could modify an original object when its address is passed.

### Unit V — Structures, Unions and Storage Classes
- Employee structure
- Union and shared-memory demonstration
- `auto`, `register`, `static` and `extern` examples
- Employee payroll report using a structure array

## Requirements
- GCC or another C11-compatible compiler
- Terminal / command prompt

## Compile and run

### Linux / macOS
```bash
gcc -std=c11 -Wall -Wextra -pedantic src/main.c -o c_toolkit
./c_toolkit
```

### Windows (MinGW GCC)
```bash
gcc -std=c11 -Wall -Wextra -pedantic src/main.c -o c_toolkit.exe
c_toolkit.exe
```

You can also use the included Makefile on systems with `make` installed:
```bash
make
./c_toolkit
```

## Example use
1. Run the program.
2. Select a unit from the main menu.
3. Choose an operation and enter the requested input.
4. Enter `0` to return to the previous menu or exit.

## Payroll formula used in this demo
- HRA = 20% of basic salary
- DA = 10% of basic salary
- PF = 12% of basic salary
- Gross salary = Basic + HRA + DA
- Net salary = Gross - PF

These rates are illustrative examples only. They are not intended to represent official payroll rules.

## Concepts demonstrated
Functions, recursion, arrays, strings, pointers, structures, unions, storage classes, loops, conditional statements, formatted input/output, linear search, sorting, and basic complexity analysis.

## Limitations / possible extensions
- This is a console application, not a web or mobile app.
- Payroll and grade rules are simplified educational examples.
- Employee records are kept in memory and are not saved after the program exits.
- Possible future improvements: file-based storage, binary search, insertion sort, menu input validation for all edge cases, unit tests, and a GUI.

## GitHub submission
1. Create a new repository named `c-programming-complete-toolkit`.
2. Upload `src/main.c`, `README.md`, `Makefile`, and `.gitignore`.
3. Add a short repository description: `Menu-driven C application covering algorithms, arrays, strings, pointers, structures, unions and payroll.`
4. Compile and test locally before submitting.
5. Include your own name, course, and college in the repository description or a project report if your instructor requires it.

## Academic integrity note
Use this as a learning starter. Read through the code, run each menu option, and be ready to explain the algorithms and C concepts during a project review. Follow your course's rules for acknowledging assistance.
