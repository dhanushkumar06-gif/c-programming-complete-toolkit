#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*
 * C Programming Complete Toolkit
 * Demonstrates algorithms, C basics, arrays/strings, functions/pointers,
 * structures/unions, storage classes, and a simple employee payroll module.
 */

#define MAX_ITEMS 100
#define MAX_NAME 50

typedef struct {
    int id;
    char name[MAX_NAME];
    float basic_salary;
} Employee;

typedef union {
    int integer_value;
    float float_value;
    char text_value[20];
} DemoUnion;

/* Function prototypes */
void unit1_menu(void);
void unit2_menu(void);
void unit3_menu(void);
void unit4_menu(void);
void unit5_menu(void);
void clear_input(void);
int read_int(const char *prompt);
float read_float(const char *prompt);
void read_line(const char *prompt, char *buffer, size_t size);
long long factorial_recursive(int n);
void fibonacci_sequence(int n);
int linear_search(const int a[], int n, int key);
void bubble_sort(int a[], int n);
int sum_digits(int n);
int are_anagrams(const char *a, const char *b);
void print_array(const int a[], int n);
void matrix_addition(void);
void string_tools(void);
void pointer_demo(void);
void array_of_pointers_demo(void);
void structure_demo(void);
void union_demo(void);
void storage_class_demo(void);
void employee_payroll(void);
void student_grade_calculator(void);
void reverse_string(char *s);
void to_lowercase(char *s);

int main(void) {
    int choice;
    printf("============================================\n");
    printf("     C PROGRAMMING COMPLETE TOOLKIT\n");
    printf("============================================\n");
    printf("A menu-driven application covering Units I-V\n");

    do {
        printf("\nMAIN MENU\n");
        printf("1. Unit I   - Problem-Solving Techniques\n");
        printf("2. Unit II  - C Programming Basics\n");
        printf("3. Unit III - Arrays and Strings\n");
        printf("4. Unit IV  - Functions and Pointers\n");
        printf("5. Unit V   - Structures, Unions and Payroll\n");
        printf("0. Exit\n");
        choice = read_int("Choose a unit: ");

        switch (choice) {
            case 1: unit1_menu(); break;
            case 2: unit2_menu(); break;
            case 3: unit3_menu(); break;
            case 4: unit4_menu(); break;
            case 5: unit5_menu(); break;
            case 0: printf("Thank you for using the toolkit!\n"); break;
            default: printf("Invalid choice. Please select 0-5.\n");
        }
    } while (choice != 0);
    return 0;
}

void clear_input(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

int read_int(const char *prompt) {
    int value;
    printf("%s", prompt);
    while (scanf("%d", &value) != 1) {
        printf("Please enter a valid integer: ");
        clear_input();
    }
    clear_input();
    return value;
}

float read_float(const char *prompt) {
    float value;
    printf("%s", prompt);
    while (scanf("%f", &value) != 1) {
        printf("Please enter a valid number: ");
        clear_input();
    }
    clear_input();
    return value;
}

void read_line(const char *prompt, char *buffer, size_t size) {
    printf("%s", prompt);
    if (fgets(buffer, (int)size, stdin) != NULL) {
        buffer[strcspn(buffer, "\n")] = '\0';
    } else {
        buffer[0] = '\0';
    }
}

void unit1_menu(void) {
    int choice;
    do {
        printf("\nUNIT I - PROBLEM-SOLVING TECHNIQUES\n");
        printf("1. Factorial (iterative and recursive)\n");
        printf("2. Fibonacci sequence\n");
        printf("3. Search an array (linear search)\n");
        printf("4. Sort an array (bubble sort)\n");
        printf("5. Sum of digits\n");
        printf("6. Check anagrams\n");
        printf("7. View algorithm and complexity notes\n");
        printf("0. Back\n");
        choice = read_int("Choose: ");

        if (choice == 1) {
            int n = read_int("Enter n (0-20): ");
            if (n < 0 || n > 20) {
                printf("Use a value from 0 to 20 for safe long long output.\n");
            } else {
                long long iterative = 1;
                for (int i = 2; i <= n; i++) iterative *= i;
                printf("Iterative factorial = %lld\n", iterative);
                printf("Recursive factorial = %lld\n", factorial_recursive(n));
            }
        } else if (choice == 2) {
            int n = read_int("How many terms (1-90)? ");
            if (n < 1 || n > 90) printf("Please enter 1-90.\n");
            else fibonacci_sequence(n);
        } else if (choice == 3 || choice == 4) {
            int n = read_int("Number of elements (1-100): ");
            if (n < 1 || n > MAX_ITEMS) { printf("Invalid size.\n"); continue; }
            int a[MAX_ITEMS];
            for (int i = 0; i < n; i++) {
                char prompt[40];
                snprintf(prompt, sizeof(prompt), "Element %d: ", i + 1);
                a[i] = read_int(prompt);
            }
            if (choice == 3) {
                int key = read_int("Value to search: ");
                int index = linear_search(a, n, key);
                if (index >= 0) printf("%d found at position %d (0-based index %d).\n", key, index + 1, index);
                else printf("%d was not found.\n", key);
            } else {
                bubble_sort(a, n);
                printf("Sorted array: ");
                print_array(a, n);
            }
        } else if (choice == 5) {
            int n = read_int("Enter an integer: ");
            printf("Sum of digits = %d\n", sum_digits(n));
        } else if (choice == 6) {
            char a[200], b[200];
            read_line("First word/text: ", a, sizeof(a));
            read_line("Second word/text: ", b, sizeof(b));
            printf("%s\n", are_anagrams(a, b) ? "They are anagrams." : "They are not anagrams.");
        } else if (choice == 7) {
            printf("\nAlgorithm: a finite sequence of clear steps to solve a problem.\n");
            printf("Good algorithm: correct, finite, unambiguous, efficient, well-defined input/output.\n");
            printf("Time complexity estimates how running time grows with input size.\n");
            printf("Space complexity estimates extra memory used.\n");
            printf("Linear search: O(n) time, O(1) extra space.\n");
            printf("Bubble sort: O(n^2) average/worst time, O(1) extra space.\n");
            printf("Factorial loop/recursion: O(n) time; recursion uses O(n) call-stack space.\n");
            printf("Pseudocode example for sum of digits:\n");
            printf("  sum = 0; while n != 0: sum += abs(n %% 10); n /= 10\n");
            printf("Flowchart idea: Start -> Input -> Process -> Output -> End.\n");
        } else if (choice != 0) printf("Invalid choice.\n");
    } while (choice != 0);
}

void unit2_menu(void) {
    int choice;
    do {
        printf("\nUNIT II - C PROGRAMMING BASICS\n");
        printf("1. Student grade calculator (input/output, operators, branching)\n");
        printf("2. Looping statements demonstration\n");
        printf("3. Constants, variables and data types notes\n");
        printf("0. Back\n");
        choice = read_int("Choose: ");
        if (choice == 1) student_grade_calculator();
        else if (choice == 2) {
            int n = read_int("Print multiplication table for: ");
            printf("for loop: ");
            for (int i = 1; i <= 10; i++) printf("%d ", n * i);
            printf("\nwhile loop: ");
            int i = 1;
            while (i <= 10) { printf("%d ", n * i); i++; }
            printf("\ndo-while loop: ");
            i = 1;
            do { printf("%d ", n * i); i++; } while (i <= 10);
            printf("\n");
        } else if (choice == 3) {
            printf("Character set: letters, digits, whitespace and special symbols.\n");
            printf("Constants: fixed values; variables: named memory locations.\n");
            printf("Common types: char, int, float, double; modifiers include short, long, signed, unsigned.\n");
            printf("Operators: arithmetic (+ - * / %%), relational, logical, assignment, increment/decrement.\n");
            printf("Input/output commonly uses scanf/printf; strings can use fgets/puts.\n");
            printf("Decision statements: if, if-else, else-if, switch. Loops: for, while, do-while.\n");
        } else if (choice != 0) printf("Invalid choice.\n");
    } while (choice != 0);
}

void unit3_menu(void) {
    int choice;
    do {
        printf("\nUNIT III - ARRAYS AND STRINGS\n");
        printf("1. One-dimensional array: sum, minimum and maximum\n");
        printf("2. Two-dimensional array: matrix addition\n");
        printf("3. String operations: length, reverse, lowercase\n");
        printf("4. Sort and search an array\n");
        printf("0. Back\n");
        choice = read_int("Choose: ");
        if (choice == 1) {
            int n = read_int("Number of elements (1-100): ");
            if (n < 1 || n > MAX_ITEMS) { printf("Invalid size.\n"); continue; }
            int a[MAX_ITEMS], sum = 0, min, max;
            for (int i = 0; i < n; i++) {
                char prompt[40]; snprintf(prompt, sizeof(prompt), "Element %d: ", i + 1);
                a[i] = read_int(prompt); sum += a[i];
                if (i == 0 || a[i] < min) min = a[i];
                if (i == 0 || a[i] > max) max = a[i];
            }
            printf("Array: "); print_array(a, n);
            printf("Sum = %d, Minimum = %d, Maximum = %d\n", sum, min, max);
        } else if (choice == 2) matrix_addition();
        else if (choice == 3) string_tools();
        else if (choice == 4) {
            int n = read_int("Number of elements (1-100): ");
            if (n < 1 || n > MAX_ITEMS) { printf("Invalid size.\n"); continue; }
            int a[MAX_ITEMS];
            for (int i = 0; i < n; i++) {
                char prompt[40]; snprintf(prompt, sizeof(prompt), "Element %d: ", i + 1);
                a[i] = read_int(prompt);
            }
            bubble_sort(a, n);
            printf("Sorted: "); print_array(a, n);
            int key = read_int("Search for: ");
            int index = linear_search(a, n, key);
            if (index >= 0) printf("Found at position %d.\n", index + 1);
            else printf("Not found.\n");
        } else if (choice != 0) printf("Invalid choice.\n");
    } while (choice != 0);
}

void unit4_menu(void) {
    int choice;
    do {
        printf("\nUNIT IV - FUNCTIONS AND POINTERS\n");
        printf("1. Recursive factorial\n");
        printf("2. Pass by value vs pass by reference\n");
        printf("3. Pointer operators demonstration\n");
        printf("4. Array of pointers demonstration\n");
        printf("0. Back\n");
        choice = read_int("Choose: ");
        if (choice == 1) {
            int n = read_int("Enter n (0-20): ");
            if (n < 0 || n > 20) printf("Use 0-20.\n");
            else printf("%d! = %lld\n", n, factorial_recursive(n));
        } else if (choice == 2) {
            int value = read_int("Enter a value: ");
            int original = value;
            int *ptr = &value;
            printf("Before: value=%d, address=%p\n", value, (void *)&value);
            value += 10; /* pass-by-value style local update */
            printf("After local update (+10): %d\n", value);
            *ptr += 5; /* pointer/reference-style update through address */
            printf("After pointer update (+5): %d\n", value);
            printf("Original copied value remains %d; pointer points to %p.\n", original, (void *)ptr);
        } else if (choice == 3) pointer_demo();
        else if (choice == 4) array_of_pointers_demo();
        else if (choice != 0) printf("Invalid choice.\n");
    } while (choice != 0);
}

void unit5_menu(void) {
    int choice;
    do {
        printf("\nUNIT V - STRUCTURES, UNIONS AND STORAGE CLASSES\n");
        printf("1. Structure demonstration\n");
        printf("2. Union memory demonstration\n");
        printf("3. Storage class demonstration\n");
        printf("4. Employee payroll application\n");
        printf("0. Back\n");
        choice = read_int("Choose: ");
        if (choice == 1) structure_demo();
        else if (choice == 2) union_demo();
        else if (choice == 3) storage_class_demo();
        else if (choice == 4) employee_payroll();
        else if (choice != 0) printf("Invalid choice.\n");
    } while (choice != 0);
}

long long factorial_recursive(int n) {
    if (n <= 1) return 1;
    return n * factorial_recursive(n - 1);
}

void fibonacci_sequence(int n) {
    unsigned long long a = 0, b = 1;
    printf("Fibonacci: ");
    for (int i = 0; i < n; i++) {
        printf("%llu", a);
        if (i < n - 1) printf(" ");
        unsigned long long next = a + b;
        a = b; b = next;
    }
    printf("\n");
}

int linear_search(const int a[], int n, int key) {
    for (int i = 0; i < n; i++) if (a[i] == key) return i;
    return -1;
}

void bubble_sort(int a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int swapped = 0;
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j]; a[j] = a[j + 1]; a[j + 1] = temp;
                swapped = 1;
            }
        }
        if (!swapped) break;
    }
}

int sum_digits(int n) {
    int sum = 0;
    if (n < 0) n = -n;
    while (n > 0) { sum += n % 10; n /= 10; }
    return sum;
}

void to_lowercase(char *s) {
    for (int i = 0; s[i]; i++) s[i] = (char)tolower((unsigned char)s[i]);
}

int are_anagrams(const char *a, const char *b) {
    int counts[256] = {0};
    for (int i = 0; a[i]; i++) {
        unsigned char c = (unsigned char)a[i];
        if (!isspace(c)) counts[(unsigned char)tolower(c)]++;
    }
    for (int i = 0; b[i]; i++) {
        unsigned char c = (unsigned char)b[i];
        if (!isspace(c)) counts[(unsigned char)tolower(c)]--;
    }
    for (int i = 0; i < 256; i++) if (counts[i] != 0) return 0;
    return 1;
}

void print_array(const int a[], int n) {
    for (int i = 0; i < n; i++) printf("%d%s", a[i], i == n - 1 ? "\n" : " ");
}

void matrix_addition(void) {
    int r = read_int("Rows (1-10): "), c = read_int("Columns (1-10): ");
    if (r < 1 || r > 10 || c < 1 || c > 10) { printf("Invalid dimensions.\n"); return; }
    int a[10][10], b[10][10];
    printf("Enter matrix A:\n");
    for (int i = 0; i < r; i++) for (int j = 0; j < c; j++) {
        char p[40]; snprintf(p, sizeof(p), "A[%d][%d]: ", i, j); a[i][j] = read_int(p);
    }
    printf("Enter matrix B:\n");
    for (int i = 0; i < r; i++) for (int j = 0; j < c; j++) {
        char p[40]; snprintf(p, sizeof(p), "B[%d][%d]: ", i, j); b[i][j] = read_int(p);
    }
    printf("A + B =\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) printf("%d ", a[i][j] + b[i][j]);
        printf("\n");
    }
}

void string_tools(void) {
    char s[300], rev[300];
    read_line("Enter a line of text: ", s, sizeof(s));
    size_t len = strlen(s);
    strcpy(rev, s);
    reverse_string(rev);
    printf("Length = %zu\n", len);
    printf("Reversed = %s\n", rev);
    to_lowercase(s);
    printf("Lowercase = %s\n", s);
}

void reverse_string(char *s) {
    size_t i = 0, j = strlen(s);
    if (j == 0) return;
    j--;
    while (i < j) {
        char temp = s[i]; s[i] = s[j]; s[j] = temp;
        i++; j--;
    }
}

void pointer_demo(void) {
    int value = read_int("Enter an integer: ");
    int *ptr = &value;
    printf("Value using variable: %d\n", value);
    printf("Address of value: %p\n", (void *)&value);
    printf("Address stored in pointer: %p\n", (void *)ptr);
    printf("Value using dereference (*ptr): %d\n", *ptr);
    (*ptr)++;
    printf("After (*ptr)++, value = %d\n", value);
}

void array_of_pointers_demo(void) {
    char *items[] = {"ECG", "EEG", "EMG", "Biomedical Engineering"};
    printf("Array of pointers to strings:\n");
    for (size_t i = 0; i < sizeof(items) / sizeof(items[0]); i++)
        printf("%zu. %s\n", i + 1, items[i]);
}

void structure_demo(void) {
    Employee e;
    e.id = read_int("Employee ID: ");
    read_line("Employee name: ", e.name, sizeof(e.name));
    e.basic_salary = read_float("Basic salary: ");
    printf("\nEmployee structure\nID: %d\nName: %s\nBasic salary: %.2f\n",
           e.id, e.name, e.basic_salary);
}

void union_demo(void) {
    DemoUnion data;
    printf("A union shares the same memory among all its members.\n");
    data.integer_value = 42;
    printf("After integer_value=42: %d\n", data.integer_value);
    data.float_value = 3.14f;
    printf("After float_value=3.14: %.2f\n", data.float_value);
    printf("Only the most recently assigned member should be read reliably.\n");
    printf("sizeof(union DemoUnion) = %zu bytes\n", sizeof(data));
}

void storage_class_demo(void) {
    static int call_count = 0;
    auto int automatic_value = 10;
    register int register_value = 20;
    extern int toolkit_global_demo;
    call_count++;
    printf("auto variable = %d (block scope, automatic lifetime)\n", automatic_value);
    printf("register variable = %d (register hint; compiler decides)\n", register_value);
    printf("static local call count = %d (retains value between calls)\n", call_count);
    printf("extern global demo value = %d\n", toolkit_global_demo);
}
int toolkit_global_demo = 100;

void employee_payroll(void) {
    int n = read_int("Number of employees (1-50): ");
    if (n < 1 || n > 50) { printf("Invalid number.\n"); return; }
    Employee employees[50];
    printf("\nPayroll assumptions: HRA=20%% of basic, DA=10%% of basic, PF=12%% of basic.\n");
    printf("These are sample rates for a programming demonstration, not official payroll advice.\n");
    for (int i = 0; i < n; i++) {
        printf("\nEmployee %d\n", i + 1);
        employees[i].id = read_int("ID: ");
        read_line("Name: ", employees[i].name, sizeof(employees[i].name));
        employees[i].basic_salary = read_float("Basic salary (>=0): ");
        if (employees[i].basic_salary < 0) employees[i].basic_salary = 0;
    }
    printf("\n================ PAYROLL REPORT ================\n");
    printf("%-8s %-20s %12s %12s %12s %12s\n",
           "ID", "Name", "Basic", "Gross", "PF", "Net");
    float total_net = 0;
    for (int i = 0; i < n; i++) {
        float basic = employees[i].basic_salary;
        float hra = basic * 0.20f, da = basic * 0.10f, pf = basic * 0.12f;
        float gross = basic + hra + da, net = gross - pf;
        total_net += net;
        printf("%-8d %-20.20s %12.2f %12.2f %12.2f %12.2f\n",
               employees[i].id, employees[i].name, basic, gross, pf, net);
    }
    printf("Total net payroll: %.2f\n", total_net);
    printf("Gross = Basic + HRA + DA; Net = Gross - PF.\n");
}

void student_grade_calculator(void) {
    char name[MAX_NAME];
    read_line("Student name: ", name, sizeof(name));
    float marks[5], total = 0;
    for (int i = 0; i < 5; i++) {
        char prompt[50]; snprintf(prompt, sizeof(prompt), "Mark %d (0-100): ", i + 1);
        marks[i] = read_float(prompt);
        if (marks[i] < 0) marks[i] = 0;
        if (marks[i] > 100) marks[i] = 100;
        total += marks[i];
    }
    float average = total / 5.0f;
    char grade;
    if (average >= 90) grade = 'A';
    else if (average >= 80) grade = 'B';
    else if (average >= 70) grade = 'C';
    else if (average >= 60) grade = 'D';
    else if (average >= 50) grade = 'E';
    else grade = 'F';
    printf("\nStudent: %s\nTotal: %.2f/500\nAverage: %.2f%%\nGrade: %c\n",
           name, total, average, grade);
    printf("Grade scale is illustrative; change it to match your institution's rules.\n");
}
